export const BUSINESS_NAME = "Guincho Auto Socorro Rocha";
export const PHONE_DISPLAY = "(38) 99842-4385";
export const PHONE_TEL = "+5538998424385";
export const WHATSAPP_E164 = "5538998424385";
export const CITY = "João Pinheiro e região";
export const ADDRESS = "Rua Álvaro José da Silva, 351 — Panorama";
export const ADDRESS_LINE = "João Pinheiro - MG, 38770-000";
export const MAPS_URL = "https://maps.app.goo.gl/9ZtANqvR3zF1rnRg9";
export const MAPS_EMBED =
  "https://maps.google.com/maps?q=-17.7298807,-46.1670691+(Guincho%20Auto%20Socorro%20Rocha)&z=16&output=embed";
export const LAT = -17.7298807;
export const LNG = -46.1670691;
export const DEFAULT_WHATSAPP_MESSAGE = "Olá, preciso de um guincho.";

export function whatsappUrl(message: string = DEFAULT_WHATSAPP_MESSAGE) {
  return `https://wa.me/${WHATSAPP_E164}?text=${encodeURIComponent(message)}`;
}

export const INCIDENT_OPTIONS = [
  { value: "pane", label: "Pane mecânica" },
  { value: "acidente", label: "Acidente" },
  { value: "pneu", label: "Pneu / estepe" },
  { value: "bateria", label: "Bateria" },
  { value: "transporte", label: "Transporte para outro estado" },
  { value: "outro", label: "Outro" },
] as const;
